# Privacy & Data Handling

- Default storage is local to the browser (`localStorage`). No server or cloud is used.  
- Users can export/download CSV and share at their discretion.  
- Sensitive health information should be stored and shared securely.  
- This prototype is for demonstration only and not intended for production use or clinical deployment.
